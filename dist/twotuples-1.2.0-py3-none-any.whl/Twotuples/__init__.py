from .Twotuples import PysentimentClasificator,TraduccionText,VaderClasificator,AsentClasificator,difuso_clasificator,Metric

