from .Twotuples import PysentimentClasificator,TraduccionText,VaderClasificator,AsentClasificator,difuso_clasificator,Metric

import pandas as pd
from pysentimiento import create_analyzer
from transformers import pipeline
import nltk #comprobar si quitando esta linea funciona el codigo
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import spacy
import asent
import numpy as np
import glob
import matplotlib.pyplot as plt
import numpy
from sklearn.metrics import classification_report, confusion_matrix